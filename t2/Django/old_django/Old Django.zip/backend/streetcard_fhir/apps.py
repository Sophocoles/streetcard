from django.apps import AppConfig


class StreetcardFhirConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'streetcard_fhir'
