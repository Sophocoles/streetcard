"""
This is for different user registration
@author:Shivam 
"""

# Register your models here.
