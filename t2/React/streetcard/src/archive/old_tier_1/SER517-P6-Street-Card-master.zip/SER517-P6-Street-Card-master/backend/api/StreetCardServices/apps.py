"""
This is auto generate file for StreetCard configuration
@author:Akash 
"""
from django.apps import AppConfig


class StreetcardConfig(AppConfig):
    name = 'api.StreetCardServices'
